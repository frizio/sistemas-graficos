function calculateStatistics(confusionMatrix, classesName)

    
    precision = diag(confusionMatrix) ./ sum(confusionMatrix,2);
    
    recall = diag(confusionMatrix) ./ sum(confusionMatrix,1)';
    
    f1Score = 2 * (precision .* recall) ./ (precision  + recall);
    
    fprintf('\t\tPrecision \t Recall \t F1-score \n');
    for i = 1:length(classesName),
        fprintf('%s: \t %5.3f \t\t %5.3f \t\t %5.3f \n', classesName{i}, precision(i), recall(i), f1Score(i));
    end
    fprintf('\n');

end