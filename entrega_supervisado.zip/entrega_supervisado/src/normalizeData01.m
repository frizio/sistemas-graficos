function out = normalizeData01(data)

%     normalizedData = zeros(size(data));
%     for i = 1:size(data,2),
%         current = data(:,i);
%         normalizedData(:,i) = (current - min(current)) / ( max(current) - min(current) );
%     end

    N = size(data,1);
    minValues = min(data);
    maxValues = max(data);

    normalizedData = (data - repmat(minValues, N, 1)) ./ ...
                     (repmat(maxValues, N, 1) - repmat(minValues, N, 1));

    out = normalizedData + eps;

end