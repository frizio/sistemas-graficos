function [out1, out2] = performKfoldOnNeuralNetworks(modelParameters, theDataset, folds, K)
    
    accuraciesStatsHistory = zeros(2, length(modelParameters));
    adjRandIndexesStatsHistory = zeros(2, length(modelParameters));
    
    % For each model...
    for i = 1:length(modelParameters),     
        
        transferFunctionHiddenLayer = modelParameters{i}{1};
        numberOfNeuronHiddenLayer = modelParameters{i}{2};
        
        accuracies = zeros(1, K);
        adjrandidxs = zeros(1, K);
        
        % For each folds...
        for k = 1:K,
            trainingIdxs = training(folds, k);
            validationIdxs = test(folds, k);

            net = feedforwardnet(numberOfNeuronHiddenLayer, 'trainlm');
            net.layers{1}.transferFcn = transferFunctionHiddenLayer;

            net = train(net, theDataset.observations(trainingIdxs,:)', ...
                             theDataset.targets(:,trainingIdxs));

            currentPredictions1toN = sim(net, theDataset.observations(validationIdxs,:)');

            currentPredictions1toN(currentPredictions1toN<0) = 0;
            currentPredictions1toN(currentPredictions1toN>0) = 1;

            currentPredictions = vec2ind(currentPredictions1toN)';

            accuracies(k) = sum(theDataset.responses(validationIdxs) == currentPredictions) / ...
                            length(currentPredictions);
            adjrandidxs(k) = adjrand(currentPredictions, theDataset.responses(validationIdxs));
        end

        accuracyMean = mean(accuracies);
        accuracyStd = std(accuracies);
        adjRandIdxMean = mean(adjrandidxs);
        adjRandIdxStd = std(adjrandidxs);

        accuraciesStatsHistory(1,i) = accuracyMean;
        accuraciesStatsHistory(2,i) = accuracyStd;

        adjRandIndexesStatsHistory(1,i) = adjRandIdxMean;
        adjRandIndexesStatsHistory(2,i) = adjRandIdxStd;

        f = figure('Name', theDataset.name, 'units', 'normalized', 'outerposition', [0, 0, 1, 1]);
        bar(1:K, [accuracies', adjrandidxs'], 1);
        xlabel('Fold number');
        ylabel('Values');
        title({ sprintf('Neural Network: Neuron in the hidden layer : %d, transfer function %s', numberOfNeuronHiddenLayer, transferFunctionHiddenLayer); ...
                sprintf('Accuracies: Mean = %5.4f; Std = %5.4f', accuracyMean, accuracyStd); ...
                sprintf('Adjusted rand indexes: Mean = %5.4f; Std = %5.4f', adjRandIdxMean, adjRandIdxStd) });
        legend('Accuracy', 'AdjRandIdx');
        print(f, fullfile('results', sprintf('kfold_nn_%s_%d', transferFunctionHiddenLayer, numberOfNeuronHiddenLayer)), '-dpng');
        close;

    end
    
    out1 = num2cell(accuraciesStatsHistory);
    out2 = num2cell(adjRandIndexesStatsHistory);
    
end