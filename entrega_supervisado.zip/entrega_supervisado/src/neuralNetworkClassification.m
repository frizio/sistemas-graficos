%% Classification with neural network - Pipeline script

%% Initialize workspace
clear; 
close all; 
clc;

% Set seed to ensure experiment repeatibility (randomness in kfold cross-validation)
rng(0, 'twister');

% Flag to decide to perform normalization of the values of each predictors (columns)
normalize = 0;

%% Dataset Importing
filename = 'dataset/breast-cancer-wisconsin.data';
tmp = importDataset(filename);

%% Dataset Preprocessing
theDataset = preprocessingBreastCancer(tmp);
clear tmp name;

%% Data Exploration 
dataExplorationGraphics(theDataset);


%% Normalization (if necessary)
if normalize,
    theDataset.observations = normalizeData01(theDataset.observations);
    dataExplorationGraphics(theDataset);
end

%% Features extraction (Dimensionality reduction - not performed)


%% Splitting the dataset in training, validation and test

idxs.testDataRatio = 0.2;   % percentual of the data used as test set of the best classifier
idxs.numberOfFolds = 10;    % number of folds for cross validation

% Use a index array to preserve memory usage
idxs.shuffle = randperm(theDataset.N);

idxs.n = round((1-idxs.testDataRatio) * theDataset.N);
idxs.trainValSet = idxs.shuffle(1 : idxs.n);
idxs.testSet = idxs.shuffle(idxs.n+1 :end);

% Folding for "K-fold stratified cross-validation"
idxs.folds = cvpartition(theDataset.responses(idxs.trainValSet), 'KFold', idxs.numberOfFolds);

close all;

%% Model selection

modelParameters = { {'tansig', 5}, {'tansig', 10}, {'tansig', 15}, {'tansig', 20}, ...
                    {'logsig', 5}, {'logsig', 10}, {'logsig', 15}, {'logsig', 20} };

numberOfModels = length(modelParameters);

neuralNetworkResults = cell(6, numberOfModels);

[neuralNetworkResults([3,4],:), neuralNetworkResults([5,6],:)] = ...
performKfoldOnNeuralNetworks(modelParameters, ...
                             theDataset, idxs.folds, idxs.numberOfFolds);
                         
figure('Name', theDataset.name, 'units', 'normalized', 'outerposition', [0, 0, 1, 1]);
subplot(1,2,1)
bar(1:numberOfModels, cell2mat(neuralNetworkResults(3,:)), 'g');
xlabel('Models')
set(gca,'XTickLabel', neuralNetworkResults(1,:));
ylabel('Accuracy Values');
title('Accuracies of the models (mean and std)');
hold on
errorbar(1:numberOfModels, cell2mat(neuralNetworkResults(3,:)), cell2mat(neuralNetworkResults(4,:)), '.r');

subplot(1,2,2)
bar(1:numberOfModels, cell2mat(neuralNetworkResults(5,:)), 'g');
xlabel('Models')
set(gca,'XTickLabel', neuralNetworkResults(1,:));
ylabel('Adjusted Rand Index Values');
title('Adjusted Rand Index of the models (mean and std)');
hold on
errorbar(1:numberOfModels, cell2mat(neuralNetworkResults(5,:)), cell2mat(neuralNetworkResults(6,:)), '.r');

% Choose the best model
% The choose is based on the max value of the rand index
[~, i] = max(cell2mat(neuralNetworkResults(3,:)));

fprintf('Best neural network model: number of neuron in hidden layer %d, transfer function %s\n', ...
         modelParameters{i}{2}, modelParameters{i}{1})

%% (Best) Model Assessment
close all;

net = feedforwardnet(modelParameters{i}{2}, 'trainlm');
net.layers{1}.transferFcn = modelParameters{i}{1};

net = train(net, theDataset.observations(idxs.trainValSet, :)', ...
                 theDataset.targets(:, idxs.trainValSet));

predictions1toN = sim(net, theDataset.observations(idxs.testSet,:)');

predictions1toN(predictions1toN<0) = 0;
predictions1toN(predictions1toN>0) = 1;

%% Model Evaluation

responses1toN = theDataset.targets(:,idxs.testSet);

[c, confusionMatrix] = confusion(responses1toN, predictions1toN);

fprintf('Confusion Matrix \n');
disp(confusionMatrix);
fprintf('Percentage Correct Classification   : %f%%\n', 100*(1-c));
fprintf('Percentage Incorrect Classification : %f%%\n', 100*c);

plotconfusion(responses1toN, predictions1toN);

% Statistics over confusion matrix
calculateStatistics(confusionMatrix, theDataset.classesName);

%% Receiver Operating Characteristic plot.
[myroc.truepos, myroc.falsepos, myroc.thresholds] = roc(responses1toN, predictions1toN);
plotroc(responses1toN, predictions1toN);
