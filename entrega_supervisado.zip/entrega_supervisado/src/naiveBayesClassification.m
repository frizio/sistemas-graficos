%% Classification with naive bayes - Pipeline script

%% Initialize workspace
clear; 
close all; 
clc;

% Set seed to ensure experiment repeatibility (randomness in kfold cross-validation)
rng(0, 'twister');

% Flag to decide to perform normalization of the values of each predictors (columns)
normalize = 0;

%% Dataset Importing
filename = 'dataset/breast-cancer-wisconsin.data';
tmp = importDataset(filename);

%% Dataset Preprocessing
theDataset = preprocessingBreastCancer(tmp);
clear tmp name;

%% Data Exploration 
dataExplorationGraphics(theDataset);


%% Normalization (if necessary)
if normalize,
    theDataset.observations = normalizeData01(theDataset.observations);
    dataExplorationGraphics(theDataset);
end

%% Features extraction (Dimensionality reduction - not performed)


%% Splitting the dataset in training, validation and test

idxs.testDataRatio = 0.2;   % percentual of the data used as test set of the best classifier
idxs.numberOfFolds = 10;    % number of folds for cross validation

% Use a index array to preserve memory usage
idxs.shuffle = randperm(theDataset.N);

idxs.n = round((1-idxs.testDataRatio) * theDataset.N);
idxs.trainValSet = idxs.shuffle(1 : idxs.n);
idxs.testSet = idxs.shuffle(idxs.n+1 :end);

% Folding for "K-fold stratified cross-validation"
idxs.folds = cvpartition(theDataset.responses(idxs.trainValSet), 'KFold', idxs.numberOfFolds);


%% Model selection

naiveBayesDistributionNames = {'normal', 'kernel', 'mn'};
numberOfModels = length(naiveBayesDistributionNames);

naiveBayesFh = @(name, observations, responses) ...
                fitcnb(observations, responses, 'DistributionNames', name);
            
naiveBayesResults = cell(6,numberOfModels);
naiveBayesResults(1,:) = naiveBayesDistributionNames;
%naiveBayesResults(2,:) = {'g', 'b', 'y'};       % Color used in plot

[naiveBayesResults([3,4],:), naiveBayesResults([5,6],:)] = ...
     performKfoldOnNaiveBayes( ...
            naiveBayesFh, naiveBayesResults(1,:), theDataset, idxs.folds, idxs.numberOfFolds);

figure('Name', theDataset.name, 'units', 'normalized', 'outerposition', [0, 0, 1, 1]);
subplot(1,2,1)
bar(1:numberOfModels, cell2mat(naiveBayesResults(3,:)), 'g');
xlabel('Models')
set(gca,'XTickLabel', naiveBayesResults(1,:));
ylabel('Accuracy Values');
title('Accuracies of the models (mean and std)');
hold on
errorbar(1:numberOfModels, cell2mat(naiveBayesResults(3,:)), cell2mat(naiveBayesResults(4,:)), '.r');

subplot(1,2,2)
bar(1:numberOfModels, cell2mat(naiveBayesResults(5,:)), 'g');
xlabel('Models')
set(gca,'XTickLabel', naiveBayesResults(1,:));
ylabel('Adjusted Rand Index Values');
title('Adjusted Rand Index of the models (mean and std)');
hold on
errorbar(1:numberOfModels, cell2mat(naiveBayesResults(5,:)), cell2mat(naiveBayesResults(6,:)), '.r');

% Choose the best model
% The choose is based on the max value of the rand index
[~, i] = max(cell2mat(naiveBayesResults(5,:)));

fprintf('Best naive bayes model: %s\n', naiveBayesResults{1,i})

%% (Best) Model Assessment
close all;

% Train the model with whole training dataset
classifier = naiveBayesFh(naiveBayesResults{1,i}, ...
                    theDataset.observations(idxs.trainValSet,:), theDataset.responses(idxs.trainValSet));

predictions = predict(classifier, theDataset.observations(idxs.testSet,:));

%% Model Evaluation

responses1toN = ind2vec(theDataset.responses(idxs.testSet)');
predictions1toN =  ind2vec(predictions');

[c, confusionMatrix] = confusion(responses1toN, predictions1toN);

fprintf('Confusion Matrix \n');
disp(confusionMatrix);
fprintf('Percentage Correct Classification   : %f%%\n', 100*(1-c));
fprintf('Percentage Incorrect Classification : %f%%\n', 100*c);

plotconfusion(responses1toN, predictions1toN);

% Statistics over confusion matrix
calculateStatistics(confusionMatrix, theDataset.classesName);

%% Receiver Operating Characteristic plot.
[myroc.truepos, myroc.falsepos, myroc.thresholds] = roc(responses1toN, predictions1toN);
plotroc(responses1toN, predictions1toN);
