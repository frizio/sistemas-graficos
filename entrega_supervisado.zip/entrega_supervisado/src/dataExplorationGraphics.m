function dataExplorationGraphics(theDataset)
    
    figure('Name', theDataset.name, 'units', 'normalized', 'outerposition', [0, 0, 1, 1]);
    subplot(2,2,[1,2]);
    plot(1:theDataset.N, theDataset.responses, '*')
    xlabel('Observation number');
    ylabel('Class');
    title('Observation"s class distribution');

    subplot(2,2,3);
    hist(theDataset.responses)
    xlabel('Class');
    ylabel('Number of Observations');
    title('Histogram');

    subplot(2,2,4);
    bar(1:theDataset.M, [min(theDataset.observations)', max(theDataset.observations)'], 1)
    title('Predictors values distribution')
    xlabel('Predictors columns')
    ylabel('Values')
    legend('Min', 'Max')

    figure('Name', theDataset.name, 'units', 'normalized', 'outerposition', [0, 0, 1, 1]);
    d = ceil(sqrt(theDataset.M));
    for i= 1:theDataset.M,
       subplot(d,d,i)
       hist(theDataset.observations(:,i));
       title(theDataset.predictorsName(i))
    end

    tabulate(theDataset.responses);
end