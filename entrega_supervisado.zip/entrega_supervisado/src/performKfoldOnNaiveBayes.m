function [out1, out2] = performKfoldOnNaiveBayes(modelFh, names, theDataset, folds, K)

    M = length(names);
    
    accuraciesStatsHistory = zeros(2, M);
    adjRandIndexesStatsHistory = zeros(2, M);
    
    % For each model...
    for i = 1:M,
        
        accuracies = zeros(1, K);
        adjrandidxs = zeros(1, K);
        
        % For each folds...
        for k = 1:K,
            trainingIdxs = training(folds, k);
            validationIdxs = test(folds, k);

            classifier = modelFh(names{i}, ...
                                       theDataset.observations(trainingIdxs,:), theDataset.responses(trainingIdxs));
            currentPredictions = predict(classifier, theDataset.observations(validationIdxs,:));

            accuracies(k) = sum(theDataset.responses(validationIdxs) == currentPredictions) / ...
                            length(currentPredictions);
            adjrandidxs(k) = adjrand(currentPredictions, theDataset.responses(validationIdxs));
        end

        accuracyMean = mean(accuracies);
        accuracyStd = std(accuracies);
        adjRandIdxMean = mean(adjrandidxs);
        adjRandIdxStd = std(adjrandidxs);
        
        accuraciesStatsHistory(1,i) = accuracyMean;
        accuraciesStatsHistory(2,i) = accuracyStd;
        
        adjRandIndexesStatsHistory(1,i) = adjRandIdxMean;
        adjRandIndexesStatsHistory(2,i) = adjRandIdxStd;
        
        f = figure('Name', 'BCW', 'units', 'normalized', 'outerposition', [0, 0, 1, 1]);
        bar(1:K, [accuracies', adjrandidxs'], 1);
        xlabel('Fold number');
        ylabel('Values');
        title({ sprintf('Bayesian model: %s', names{i}); ...
                sprintf('Accuracies: Mean = %5.4f; Std = %5.4f', accuracyMean, accuracyStd); ...
                sprintf('Adjusted rand indexes: Mean = %5.4f; Std = %5.4f', adjRandIdxMean, adjRandIdxStd) });
        legend('Accuracy', 'AdjRandIdx');
        print(f, fullfile('results', sprintf('kfold%d_%s',i,names{i})), '-dpng');
        close;

    end
    
    out1 = num2cell(accuraciesStatsHistory);
    out2 = num2cell(adjRandIndexesStatsHistory);
    
end