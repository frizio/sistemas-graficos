function out = preprocessingBreastCancer(X)
% Preprocessing Breast Cancer Dataset and generate the data structure where
% store the data ready for machine learning task.
% 
% 1. Eliminate entire row if there is at least one NaN value.
% 2. Convert class labels from 2, 4 to 1, 2 (for the ind2vec function)
% 3. Generate "structure array" data structure.
%
% Detail of the output value:
% .identifiers
% .observations
% .targets
% .responses
% .predictorsName
% .classesName
% .N
% .M
% .numberOfClasses
%
% Detail on Breast Cancer Dataset
% http://archive.ics.uci.edu/ml/datasets/Breast+Cancer+Wisconsin+%28Original%29
% This breast cancer databases was obtained from the University of Wisconsin Hospitals, Madison 
% from Dr. William H. Wolberg.
%
% Attribute Information:
% 1. Sample code number: id number
% 2. Clump Thickness: 1 - 10
% 3. Uniformity of Cell Size: 1 - 10
% 4. Uniformity of Cell Shape: 1 - 10
% 5. Marginal Adhesion: 1 - 10
% 6. Single Epithelial Cell Size: 1 - 10
% 7. Bare Nuclei: 1 - 10
% 8. Bland Chromatin: 1 - 10
% 9. Normal Nucleoli: 1 - 10
% 10. Mitoses: 1 - 10
% 11. Class: (2 for benign, 4 for malignant)
%
% Usage
% Attributes 2 through 10 have been used to represent instances.
% Each instance has one of 2 possible classes: benign or malignant.

invalidObservations = [];
for row=1 : size(X,1),
   if (sum(isnan(X(row, :))) > 0)     % Annotate row for deletion if there is at least one NaN value.
        invalidObservations = [invalidObservations, row];
   else     % Convert class labels from 2, 4 to 1, 2 
       if X(row, end) == 2,
            X(row, end) = 1;
        else
            X(row, end) = 2;
       end
   end
end
X(invalidObservations,:) = [];

% Generate theDataset data structure.
theDataset.name = 'Breast Cancer Wisconsin';
theDataset.identifiers = X(:, 1);
theDataset.observations = X(:, 2:end-1);
theDataset.responses = X(:, end);
theDataset.targets = ind2vec(theDataset.responses');
theDataset.predictorsName = {'clump Thickness', 'uniformity cell size', ...
                             'uniformity cell shape', 'marginal adhesion', ...
                             'single epithelial cell size', 'bare nuclei' ...
                             'bland chromatin', 'normal nucleoli', 'mitoses' };
theDataset.classesName = {'benign', 'malignant'};

theDataset.N = size(theDataset.observations, 1);
theDataset.M = size(theDataset.observations, 2);
theDataset.numberOfClasses = length(unique(theDataset.responses));

disp(theDataset);
out = theDataset;

end