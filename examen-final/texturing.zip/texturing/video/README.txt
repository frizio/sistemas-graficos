The page texture_video_test.html is only a text where I learn to texture a video inside a canvas.
The final file is texture_video.html and the relative javascript file texture_video.js.
