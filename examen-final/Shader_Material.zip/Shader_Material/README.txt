Not work :
I work on phase, normalInterp, normalMatrix