/* Legend
[operation,
 translate_x, translate_y, translate_z,
 scale_x, scale_y, scale_z,
 rot_angle, rotate_x, rotate_y, rotate_z];
*/

/*
var secuencia_operaciones = [
["t",   30,-30,0,    0,0,0,    0,0,0,0],
["r",   0,0,0,       0,0,0,    45,1,0,0],
["t",   -30,30,0,    0,0,0,    0,0,0,0],
]
*/

/*
var secuencia_operaciones = [
["t",   50,0,0,    0,0,0,    0,0,0,0]
]
*/

var secuencia_operaciones = [
["t",   -200,0,0,    0,0,0,    0,0,0,0],
["r",   0,0,0,     0,0,0,    90,1,0,0],
["t",   0,150,0,    0,0,0,    0,0,0,0],
]


/*
var secuencia_operaciones = [
["t",   -200,0,0,    0,0,0,    0,0,0,0],
["r",   0,0,0,     0,0,0,    90,0,1,0],
//["t",   0,150,0,    0,0,0,    0,0,0,0],
//["s",   0,0,0,    0.5,0.5,0.5,    0,0,0,0],
]
*/
