To download the mat-files that contain the models use the following public dropbox link

https://www.dropbox.com/s/fv9a8h7q0piw7je/faceClassifierSVM.mat?dl=0

https://www.dropbox.com/s/wjjykxinsu95zdm/retrained-vgg-16_nottrained.mat?dl=0

