function [out1, out2, out3] = facialRecognizerSVM(faceClassifier, face)
% Function that use the support vector machine trained model
% to predict the label of the input face.
% Return the class label and the score
    
    % Feature Extraction
    %features = extractHOGFeatures(rgb2gray(face));
    
    normalizedFace = imresize(rgb2gray(face), [150, 150]);
    features = extractHOGFeatures(normalizedFace);
    
    % Generating Prediction
    [label, score, ~, prob] = predict(faceClassifier, features);

    out1 = label;
    out2 = max(prob); %max(score .* prob);
    out3 = prob;

end