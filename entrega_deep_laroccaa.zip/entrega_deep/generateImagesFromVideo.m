function generateImagesFromVideo()
% Function that processing the initial folders of videos.
% Video in the training folder: extract one frame each three and extract the faces
% Video in the test folder: extract one frame each three and extract the faces

    %% Clean the workspace
    clear; close all; clc;

    %% Set Dataset input and output folders
    %folder.home = '/media/Archivio/Datasets/Multimedia/entrega_deep';
    folder.home = 'data';

    % Input folder
    folder.videos  = fullfile(folder.home,  'videos');

    % Output folders
    folder.faces = fullfile(folder.home,  'faces');
    folder.frames = fullfile(folder.home,  'frames');

    load('mat-files/cameraParams.mat');

    %% Processing training video storing one frame each five
    filenames = extractfield(dir(fullfile(folder.videos, 'training')), 'name');
    for i=3 : length(filenames),
        filename  = fullfile(fullfile(folder.videos, 'training'), filenames{i});
        extractFacesFromVideo(filename, fullfile(folder.faces, 'training'), cameraParams, 5, 128);
    end

    %% Processing test video storing all frames
    filenames = extractfield(dir(fullfile(folder.videos, 'test')), 'name');
    for i=3 : length(filenames),
        filename  = fullfile(fullfile(folder.videos, 'test'), filenames{i});
        extractFramesFromVideo(filename, fullfile(folder.frames, 'test'), cameraParams, 1);
        %extractFacesFromVideo(filename, fullfile(folder.faces, 'test'), cameraParams, 6, 128);
    end

end
