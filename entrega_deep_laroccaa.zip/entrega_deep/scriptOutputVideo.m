%% Script that create the output video from a sequence of image

clear; close all; clc;

%% Set debug variable equal to a value listed below, to perform different task
% 1 loading previous trained SVM
% 2 loading a pretrained CNN
%%%%%%%%%%%%
DEBUG = 2; %
%%%%%%%%%%%%

%% Dataset input and output folders
%folder.home = '/media/Archivio/Datasets/Multimedia/entrega_deep';
folder.home = 'data';

folder.input  = fullfile(folder.home, 'frames', 'test', 'secuencia2'); %secuencia1
folder.output  = fullfile(folder.home,  'results');

%% Input images
filenames = sort_nat(extractfield(dir(folder.input), 'name'));

%% Output video
outputVideo = VideoWriter(fullfile(folder.output, 'sequencia2_annotatedByCNN.avi')); %'sequencia1_annotated.avi'
outputVideo.FrameRate = 30;
open(outputVideo)

%% Face Detector
faceDetector = vision.CascadeObjectDetector('FrontalFaceCART');

%% Classifier used

% SVM (fast trainined)
load('models/faceClassifierSVM.mat');

% CNN
net = load('/media/Archivio/Experiments/pretrained-deepnet/retrained-vgg-16_nottrained.mat');
%net = load('models/retrained-vgg-16_nottrained.mat');


%% Video generation

% figure('units', 'normalized', 'outerposition', [0, 0, 1, 1]);

for i = 3 : length(filenames),
    
    % Current image
    frame = imread(fullfile(folder.input, filenames{i}));
    
    % Detect faces
    bboxes = step(faceDetector, frame);
    
    if size(bboxes, 1) ~= 0, % a face is detected
    
        % Image croping
        face = imcrop(frame, bboxes(1,:));

        % Face Recognition
        %[label, prob, ~] = facialRecognizerSVM(faceClassifier, face);
        [label, prob, ~] = facialRecognizerCNN(net, face);
        
        %dlabel = 'face';
        dlabel = sprintf('%s - %2.2f', label{1}, prob);
        
        % Annotate detected faces
        frame = insertObjectAnnotation(frame, 'rectangle', bboxes, dlabel, 'Color', 'green');
    end
    
%     imagesc(frame);
%     drawnow expose; 
    
    writeVideo(outputVideo, frame);
    
end
close(outputVideo);

