function mainFunction()
    % Main function of the pipeline used to develop the project

    %% Clean the workspace
    clear; close all; clc;

    %% Image acquisition from video
    if true,
        generateImagesFromVideo();
    end
    clc;
    
    %% Dataset struct generation (used to training the deep NN)
    imdb = generateImageDataset();

    %% Define my deep convolutional neural network (to play and investigate on filter dimensions)
    % net = dummyFaceCNN();
    % vl_simplenn_display(net);

    %% or (better) Transfer Learning from vgg-16 deepnet
    transferLearning(imdb);
    
    %%
    

end

