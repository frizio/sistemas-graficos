function extractFacesFromVideo(inputFilename, outputFolder, cameraParametes, k, d)
% Function that extract frames from video and detect faces from the frames.
% Faces are stored in a folder (one each k and resized with dimension d x d).

    if ~exist(outputFolder, 'dir'),
        mkdir(outputFolder);
    end

    [~, name, ~] = fileparts(inputFilename);
    foldername = fullfile(outputFolder, name);

    if ~exist(foldername, 'dir'),
        fprintf('\n%s processing...\n', name);
        mkdir(foldername);

        videoFileReader = vision.VideoFileReader(inputFilename);
        videoPlayer = vision.VideoPlayer;
        set(findall(0, 'tag', 'spcui_scope_framework'), 'position',[0, 32, 800, 600]);
        
        % Faces Detecor Object
        faceDetector = vision.CascadeObjectDetector('FrontalFaceCART');

        i = 0;
        j = 0;
        while ~isDone(videoFileReader),
            i = i + 1;
            frame = step(videoFileReader);
            undistortedFrame = undistortImage(frame, cameraParametes);
            if (mod(i, k) == 0),
                
                % Faces Detection
                bboxes = step(faceDetector, undistortedFrame);

                % Faces Registration
                for b=1 : size(bboxes, 1),  
                    j = j+1;
                    % Image croping
                    face = imcrop(undistortedFrame, bboxes(b,:));
                    % Image re-scaling
                    face = imresize(face, [d, d]);
                    % Image storing
                    imwrite( face, fullfile(outputFolder, name,  sprintf('%d_faces%d.png', i, b)) );
                end
                
            end
            step(videoPlayer, frame);
        end
        release(videoFileReader);
        release(videoPlayer);
        disp([name, ': Number of frames processed = ', num2str(i), ...
                    ', Number of faces stored = ', num2str(j), '.'])
    else
        fprintf('%s previous processed.\n', name);
    end

end
