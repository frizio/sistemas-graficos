function DemoFaceRecognition()
% Face Recognition example using Machine Learning.
% Before executing them, use the variable DEBUG.

%%
%clear; close all; clc;

%% Set debug variable equal to a value listed below, to perform different task
% 0 training a new SVM classifier
% 1 loading previous trained SVM
% 2 loading a pretrained CNN
%%%%%%%%%%%%
DEBUG = 1; %
%%%%%%%%%%%%

%% Dataset folder
%folder.home = '/media/Archivio/Datasets/Multimedia/entrega_deep/faces';
folder.home = 'data/faces';

folder.trainingImages = fullfile(folder.home, 'training');
folder.testImages = fullfile(folder.home, 'test', 'secuencia1'); % 'secuencia2'

%% Load Training set
trainingSet = generateSvmTrainingSet(folder.trainingImages);

% Models
if DEBUG == 0,
    name = 'New SVM';
    % Create Classifier and training a multiclass SVM
    faceClassifier = fitcecoc(trainingSet.features, trainingSet.labels, ...
                              Learners, 'svm', 'FitPosterior', true);
else
    if DEBUG == 1,
        name = 'Pretrained SVM';
        % Load the SVM classifier previous trained
        load('models/faceClassifierSVM.mat');
    else
        name = 'Pretrained CNN';
        % Load the CNN
        net = load('/media/Archivio/Experiments/pretrained-deepnet/retrained-vgg-16_nottrained.mat');
        %net = load('models/retrained-vgg-16_nottrained.mat');
    end
end

%% Testing the model
close all;

classes = trainingSet.classes;  % only to have a list of class labels.
images = trainingSet.images;    % only to help to visualize a rappresentative image of the class.

% Read test data
testSet = imageSet(folder.testImages);
figure('units', 'normalized', 'outerposition', [0, 0, 1, 1]);

for i = 1 : testSet.Count,
    
    % Current test image
    queryImage = read(testSet, i);
    
    if DEBUG == 2,
        % Generating prediction using CNN
        [label, ~, allProbs] = facialRecognizerCNN(net, queryImage);
    else
        % Feature Extraction and generating Prediction using SVM
        [label, ~, allProbs] = facialRecognizerSVM(faceClassifier, queryImage);
    end
    
    % Display the result
    mask = strcmp(label, classes);
    
    subplot(1, 3, 1); 
    imshow(queryImage); 
    title('Query Face');
    
    subplot(1, 3, 2); 
    imshow(read(images(mask), 1)); 
    title(['Matched Class ', label]);
    
    subplot(1, 3, 3); 
    bar(allProbs + eps, 0.4);
    axis([0, 10, 0, 1]); 
    axis square; 
    set(gca, 'XTickLabel', classes, 'XTickLabelRotation', -45);
    title([name, ' Results']);
    
    pause(3);
    
end
close all;

%% Istruction to visualize the HOG features
% close;
% image = read(testSet, 3);
% [featureVector, hogVisualization] = extractHOGFeatures(image); 
% 
% figure('units', 'normalized', 'outerposition', [0, 0, 1, 1]);
% subplot(1, 2, 1); 
% imshow(image);
% title('Image');
% 
% subplot(1, 2, 2); 
% plot(hogVisualization)
% title('Hog Features');

end



function out = generateSvmTrainingSet(trainingImagesFolder)

    % Load Training set
    trainingImageSet = imageSet(trainingImagesFolder, 'recursive');

    classes = {trainingImageSet.Description};        % Label of each classes in training set
    displayFaceGallery(trainingImageSet, classes);

    % Initialize same data structure that will be useful in training and test phases
    L = length(classes);                             % Number of classes  in the training set
    N = sum( [trainingImageSet(1:L).Count] );        % Number of examples in the training set

    trainingFeatures = zeros(N, 10404);         % Features size (10404) depends on HoG parameters
    trainingLabels = cell(1, N);

    %% HoG training features extractions
    idxExample = 1;

    for i = 1 : L,  
        for j = 1 : trainingImageSet(i).Count,

            % Current Training Image
            currentTrainingImage = read(trainingImageSet(i), j);
            
            % Feature Extraction
            normalizedImage = imresize(rgb2gray(currentTrainingImage), [150, 150]);
            trainingFeatures(idxExample,:) = extractHOGFeatures(normalizedImage);

            trainingLabels{idxExample} = trainingImageSet(i).Description;    
            idxExample = idxExample + 1;

        end
    end

    out.images = trainingImageSet;
    out.classes = classes;
    out.numberOfClasses = L;
    out.numberOfImages = N;
    out.features = trainingFeatures;
    out.labels = trainingLabels;

end


