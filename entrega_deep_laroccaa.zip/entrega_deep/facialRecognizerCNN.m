function [out1, out2, out3] = facialRecognizerCNN(net, face)
% Function that use the deep convolution neural network retrained
% to predict the label of the input face.
% Return the class label and the score.
    
    facePreprocessed = single(imresize(face, net.normalization.imageSize(1:2)));
    facePreprocessed = facePreprocessed - net.normalization.averageImage;

    %% Run the CNN and predict the class
    res = vl_simplenn(net, facePreprocessed);

    %% Show the classification result
    scores = squeeze(gather(res(end).x)) ;
    [bestScore, best] = max(scores) ;

    label = net.classes.description{best};
    
    out1 = {label};
    out2 = bestScore;
    out3 = scores;

end