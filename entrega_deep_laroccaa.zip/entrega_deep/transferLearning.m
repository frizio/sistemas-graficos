function transferLearning(imdb)
% Function

    %% Load vgg-16 deepnet
    % Pre-trained networks directory
    %dirnet = '/media/Archivio/Experiments/pretrained-deepnet';
    dirnet = 'models';
    
    net = load(fullfile(dirnet, 'imagenet-vgg-verydeep-16.mat'));
    vl_simplenn_display(net);

    %% Modify the structure of the vgg-16 network to apply my knowlegde (the imdb faces dataset).
    % Cut the two last layers of the net
    net.layers(end) = [];
    net.layers(end) = [];

    % Add two layers costumized for output class
    net.layers{end+1} = struct('type', 'conv', ...
                               'filters', 0.01 * randn(1, 1, 4096, 9, 'single'),...
                               'biases', zeros(1, 9, 'single'), ...
                               'stride', 1, ...
                               'pad', 0);

    net.layers{end+1} = struct('type', 'softmax');
                           
    % Add loss layer needed in the training phase
    net.layers{end+1} = struct('type', 'softmaxloss');
    %net.layers{end+1} = struct('type', 'loss');

    vl_simplenn_display(net);

    %% TL-step2: Training the new network

    trainOpts.batchSize = 100 ;
    trainOpts.numEpochs = 2; %15 ;
    trainOpts.continue = true ;
    trainOpts.useGpu = false ;
    trainOpts.learningRate = 0.001 ;
    trainOpts.expDir = fullfile(dirnet, 'exp_transferLearning');
    trainOpts = vl_argparse(trainOpts, []); %varargin);

    %% TL-step2. Call training function in MatConvNet
    [net, info] = cnn_train(net, imdb, @getBatch, trainOpts);
    %[net, info] = cnn_train(net, imdb, @getBatchWithJitter, trainOpts);

    %% TL-step3, Save the result for later use
    % Cut the last layer (the softmaxloss layer)
    net.layers(end) = [] ;
    
    % Store the class names that the network will predict
    net.classes.name = imdb.meta.classes;
    net.classes.description = imdb.meta.classes;
    % Save the mean of all image (used in preprocessing phase before predictions)
    net.normalization.averageImage = imageMean;
    
    save(fullfile(dirnet, 'retrained-vgg-16.mat'), '-struct', 'net');   %retrained-vgg-16_nottrained.mat

end

%% --------------------------------------------------------------------
function [im, labels] = getBatch(imdb, batch)
% ---------------------------------------------------------------------
    im = imdb.images.data(:, :, :, batch);
    %im = 256 * reshape(im, 128, 128, 3, 1, []);
    %im = 255 * imdb.images.data(:, :, :, batch);
    %im = 256 * reshape(im, 32, 32, 1, []);     & values from chars-exp
    
    labels = imdb.images.label(1, batch);
end

%% --------------------------------------------------------------------
function [im, labels] = getBatchWithJitter(imdb, batch)
% ---------------------------------------------------------------------
    im = imdb.images.data(:,:,:,batch) ;
    labels = imdb.images.label(1,batch) ;

    n = numel(batch) ;
    train = find(imdb.images.set == 1) ;

    sel = randperm(numel(train), n) ;
    im1 = imdb.images.data(:,:,sel) ;

    sel = randperm(numel(train), n) ;
    im2 = imdb.images.data(:,:,sel) ;

    ctx = [im1 im2] ;
    ctx(:,17:48,:) = min(ctx(:,17:48,:), im) ;

    dx = randi(11) - 6 ;
    im = ctx(:,(17:48)+dx,:) ;
    sx = (17:48) + dx ;

    dy = randi(5) - 2 ;
    sy = max(1, min(32, (1:32) + dy)) ;

    im = ctx(sy,sx,:) ;

    % Visualize the batch:
    % figure(100) ; clf ;
    % vl_imarraysc(im) ;

    im = 256 * reshape(im, 32, 32, 1, []);

end