function out = generateImageDataset()
% Function that generate a struct data structure in the format used by the
% MatConvNet Toolbox to training the neural network 

    %% Clean the workspace
    %clear; close all; clc;

    %% Set Dataset folder
    %datasetFolder = '/media/Archivio/Datasets/Multimedia/entrega_deep';
    datasetFolder = 'data';
    
    imagesFolder = fullfile(datasetFolder, 'faces', 'training');

    facesSet = imageSet(imagesFolder, 'recursive');

    classes = {facesSet.Description};

    %displayFaceGallery(facesSet, classes);

    %%
    nI = sum([facesSet.Count]);
    nC = length(facesSet);

    ids = zeros(1, nI);
    datas = single(zeros(128, 128, 3, nI));
    labels = zeros(1, nI);
    classDescriptions = cell(1, nI);
    filenames = cell(1, nI);

    %sets = zeros(1, nI);
    sets= [];

    % The 70 % of the images in each class will be the training set (sets values = 1).
    % The remaining 30 % will be the validation set (sets values = 2).
    p = 0.7;

    id = 0;
    for i = 1:nC,
        ni = facesSet(i).Count;
        for j = 1:ni,
            id = id + 1;
            ids(id) = id;
            filename = facesSet(i).ImageLocation{j};
            datas(:,:,:,id) = im2single(imread(filename));
            labels(id) = i;
            classDescriptions{id} = facesSet(i).Description;
            filenames{id} = filename;
        end
        si = zeros(1, ni);
        pi = round(p * ni);
        si(1:pi) = 1;
        si(pi+1:end) = 2;
        sets = [sets, si];
    end

    %%
    imageDatabase = struct('meta', struct(), 'images', struct());


    imageDatabase.images.id = ids;
    imageDatabase.images.data = datas;
    imageDatabase.images.label = labels;
    imageDatabase.images.classDescription = classDescriptions;
    imageDatabase.images.filename = filenames;
    imageDatabase.images.set = sets;

    imageMean = mean(imageDatabase.images.data(:));
    %imageDatabase.images.data = imdb.images.data - imageMean;
    
    imageDatabase.meta.classes = classes;
    imageDatabase.meta.sets = {'train', 'val'};
    imageDatabase.meta.fonts = {};

    out = imageDatabase;

end