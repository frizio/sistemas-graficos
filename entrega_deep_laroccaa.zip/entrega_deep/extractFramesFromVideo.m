function extractFramesFromVideo(inputFilename, outputFolder, cameraParameters, k)
% Function that extract frames from video and store it as images in a folder
% Frames are stored in a folder (one each k).

    if ~exist(outputFolder, 'dir'),
        mkdir(outputFolder);
    end

    [~, name, ~] = fileparts(inputFilename);
    foldername = fullfile(outputFolder, name);

    if ~exist(foldername, 'dir'),
        fprintf('\n%s processing...\n', name);
        mkdir(foldername);

        videoFileReader = vision.VideoFileReader(inputFilename);
        videoPlayer = vision.VideoPlayer;
        set(findall(0, 'tag', 'spcui_scope_framework'), 'position',[0, 32, 800, 600]);

        i = 0;
        j = 0;
        while ~isDone(videoFileReader),
            i = i + 1;
            frame = step(videoFileReader);
            undistortedFrame = undistortImage(frame, cameraParameters);
            if (mod(i, k) == 0),
                j = j+1;
                imwrite(undistortedFrame, fullfile(outputFolder, name, [num2str(i), '.png']));
            end
            step(videoPlayer, frame);
        end
        release(videoFileReader);
        release(videoPlayer);
        disp([name, ': Number of frames processed = ', num2str(i), ...
                    ', Number of frames stored = ', num2str(j), '.'])
    else
        fprintf('%s previous processed.\n', name);
    end

end
